# scala-linear-search
*Example Linear Search in Scala*

# lisp-linear-search
*Example Linear Search in Lisp*

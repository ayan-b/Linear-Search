# groovy-linear-search
*Example Linear Search in Groovy*

def nums = [1, 2, 3, 8, 9, 12]
def target = 2

if (nums.indexOf(target) >= 0) {
    println "Successful Search!"
} else {
    println "Not in the array."
}
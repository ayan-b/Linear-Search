# dart-linear-search
*Example Linear Search in Dart*

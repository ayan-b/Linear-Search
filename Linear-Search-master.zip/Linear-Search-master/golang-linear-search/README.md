# golang-linear-search
*Example Linear Search in Golang*

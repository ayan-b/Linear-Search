# swift-linear-search
*Example Linear Search in Swift*

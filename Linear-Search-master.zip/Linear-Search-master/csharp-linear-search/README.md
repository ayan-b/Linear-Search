# csharp-linear-search
*Example Linear Search in Csharp*
# csharp-linear-search-2
*The code is pretty straight forward. Here are the steps to run the algorithm:*
1) Run the code in interactive mode
2) You will need to provide the length of array, elements of array and the value to be searched in array using Linear Search
3) You will be shown the result message if the element was found or not. That's it. Happy Coding!

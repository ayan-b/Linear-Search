# Assembly(8086 microprocessor) - linear-search

Example Linear Search in Assembly

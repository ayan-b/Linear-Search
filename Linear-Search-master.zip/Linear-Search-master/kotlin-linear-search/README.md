# kotlin-linear-search
*Example Linear Search in Kotlin*

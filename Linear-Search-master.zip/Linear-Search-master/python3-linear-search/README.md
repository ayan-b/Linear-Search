# python3-linear-search
*Example Linear Search in Python 3.7*

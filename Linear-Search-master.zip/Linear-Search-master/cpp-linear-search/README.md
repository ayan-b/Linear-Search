# cpp-linear-search
*Example Linear Search in Cpp*

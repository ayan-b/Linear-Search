# python-linear-search
*Example Linear Search in Python*
# python-linear-search
 Enter the size 'n' of the list you want to search, followed by inputing the space seperated elements
 and then enter the element to search and the output will be the index of the element between 0 to n-1
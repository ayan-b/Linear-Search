# haskell-linear-search
*Example Linear Search in Haskell*

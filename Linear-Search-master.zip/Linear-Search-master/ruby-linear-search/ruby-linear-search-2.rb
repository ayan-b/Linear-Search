def linearsearch(needle, haystack)
  haystack.index(needle)
end

puts linearsearch(1, [1,2,3,4,5,6])

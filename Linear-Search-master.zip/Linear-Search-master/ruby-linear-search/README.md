# ruby-linear-search
*Example Linear Search in Ruby*

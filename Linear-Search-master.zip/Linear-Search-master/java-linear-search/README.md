# java-linear-search
*Example Linear Search in Java*

# java-linear-search-2
**Added features in version 2:**
<ol>
<li>Added JavaDoc</li>
<li>Only one class</li>
<li>Better code structure</li>
<li>Better testing</li>
</ol>

# java-linear-search-3
<i>Easily understandable implementation</i>

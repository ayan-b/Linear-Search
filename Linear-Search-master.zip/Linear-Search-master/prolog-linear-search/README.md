# prolog-linear-search
*Example Linear Search in Prolog*
- gprolog
- consult('prolog-linear-search.pl').

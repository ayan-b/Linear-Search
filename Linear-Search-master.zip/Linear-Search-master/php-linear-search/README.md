# php-linear-search
*Example Linear Search in Php*

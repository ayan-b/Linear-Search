# c-linear-search
*Example Linear Search in C*

# turing-linear-search
*Example Linear Search in Turing*

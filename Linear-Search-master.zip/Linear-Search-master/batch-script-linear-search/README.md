# batch-script-linear-search
*Example Linear Search in Batch-script*

### batch-script-linear-search.bat
Call batch script like below: 
``` bash
batch-script-linear-search.bat <arg1> <arg2>
```
**Argument :**
 - **arg1**: List of strings (possible separated by space, semicolon, comma)
   *ex. "AA BB CC" or "AA;BB;CC"*
 - **arg2**: Target string
   *ex. AA*